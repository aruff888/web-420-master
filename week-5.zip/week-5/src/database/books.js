const Collection = require("./collection");

const books = new Collection([
  { id: 1, title: "The Hobbit", author: "J.R.R. Tolkien" },
  { id: 2, title: "1984", author: "George Orwell" }
]);

module.exports = books;
